// src/components/Navbar.jsx
import React, { useContext } from 'react'
import { Link } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'

const Navbar = () => {
  const { user, logout } = useContext(AuthContext)

  return (
    <nav className="bg-white dark:bg-zinc-900 shadow-md py-4 px-6">
      <div className="container mx-auto flex items-center justify-between">
        {/* Left - Logo / Home */}
        <div>
        <Link to="/" className="text-xl font-bold text-red-600 hover:text-red-700 transition">
  BookSwap
</Link>

        </div>

        {/* Right - Nav Links */}
        <ul className="flex gap-6 items-center text-zinc-700 dark:text-zinc-200 text-sm font-medium">
          {user ? (
            <>
              <li>
                <Link to="/my-books" className="hover:text-indigo-600 transition">My Books</Link>
              </li>
              <li>
                <Link to="/add-book" className="hover:text-indigo-600 transition">Add Book</Link>
              </li>
              <li>
                <Link to="/search-books" className="hover:text-indigo-600 transition">Search</Link>
              </li>
              <li>
                <Link to="/profile" className="hover:text-indigo-600 transition">Profile</Link>
              </li>
              <li>
                <Link to="/clubs" className="hover:text-indigo-600 transition">Clubs</Link>
              </li>

              {/* Only for Admins */}
              {user.is_admin && (
                <li>
                  <Link
                    to="/admin"
                    className="text-blue-600 hover:text-blue-800 font-semibold transition"
                  >
                    Admin
                  </Link>
                </li>
              )}

              <li>
                <button
                  onClick={logout}
                  className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl transition"
                >
                  Logout
                </button>
              </li>
            </>
          ) : (
            <>
              <li>
                <Link
                  to="/signup"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl transition"
                >
                  Sign Up
                </Link>
              </li>
              <li>
                <Link
                  to="/login"
                  className="border border-indigo-600 text-indigo-600 hover:bg-indigo-100 px-4 py-2 rounded-xl transition"
                >
                  Log In
                </Link>
              </li>
            </>
          )}
        </ul>
      </div>
    </nav>
  )
}

export default Navbar
