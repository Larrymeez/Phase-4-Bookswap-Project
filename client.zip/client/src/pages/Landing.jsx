// src/pages/Landing.jsx
import { Link } from "react-router-dom";

const Landing = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-100 to-stone-100 dark:from-zinc-900 dark:to-zinc-800 flex flex-col items-center justify-center px-4 py-12">
      <div className="max-w-3xl w-full px-8 py-14 bg-white dark:bg-zinc-800 rounded-3xl shadow-2xl text-center space-y-8">
        <h1 className="text-5xl font-extrabold text-zinc-900 dark:text-white tracking-tight">
          📚 Welcome to <span className="text-indigo-600">BookSwap</span>
        </h1>
        <p className="text-xl text-zinc-700 dark:text-zinc-300 leading-relaxed max-w-xl mx-auto">
          Discover, exchange, and connect through your love for books. Join clubs, share your reads, and build your bookshelf.
        </p>

        <div className="flex justify-center gap-8 pt-8">
          <Link
            to="/signup"
            className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-400 transition"
          >
            Get Started
          </Link>
          <Link
            to="/login"
            className="px-8 py-3 border-2 border-indigo-600 text-indigo-600 rounded-xl font-semibold hover:bg-indigo-100 focus:outline-none focus:ring-4 focus:ring-indigo-300 transition"
          >
            Login
          </Link>
        </div>
      </div>

      <footer className="mt-12 w-full text-center py-5 bg-white dark:bg-zinc-900 shadow-inner rounded-t-3xl">
        <p className="text-sm text-zinc-600 dark:text-zinc-400 select-none">
          &copy; {new Date().getFullYear()} BookSwap. All rights reserved.
        </p>
      </footer>
    </div>
  );
};

export default Landing;
